---
name: 'Relatório de erro '
about: Criar um relatório
title: "[BUG]"
labels: Assinatura, Fix
assignees: ''

---

# Pré-requisitos

- [ ] O problema está ocorrendo em PRODUÇÃO
- [ ] O problema está ocorrendo em DESENVOLVIMENTO

**Descreva o problema**
Uma descrição clara e concisa do que é o bug.

**Passos para reproduzir**
Passos para reproduzir o comportamento:

1. Acesse '...'
2. Clique em '....'
3. Role até '....'

**Capturas de tela**
Se aplicável, adicione capturas de tela para ajudar a explicar o problema.

**Quem está por dentro do assunto?**
Informe nomes das pessoas envolvidas no projeto.
