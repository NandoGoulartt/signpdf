---
name: 'Solicitação de implementação '
about: Sugira uma ideia para este projeto
title: "[FEAT]"
labels: Assinatura, Feat
assignees: ''

---

**Sua solicitação de implementação está relacionada a um problema? Por favor descreva.**
Uma descrição clara e concisa de qual é o problema. Ex. Eu sempre fico frustrado quando [...]

**Descreva a solução que você gostaria**
Uma descrição clara e concisa do que você quer que aconteça.

**Descreva as alternativas que você considerou**
Uma descrição clara e concisa de quaisquer soluções ou recursos alternativos que você considerou.

**Quem está por dentro do assunto?**
Informe nomes das pessoas envolvidas no projeto
