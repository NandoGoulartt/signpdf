## How to run

### Install dependencies

```bash
npm install
```

### Run the seed

```bash
npm run seed
```

### Run the server

```bash
npm run dev
```
